package com.edu.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.Course;
import com.edu.error.GlobalExceptionHandling;
import com.edu.service.CourseService;

@RestController
public class CourseController 
{
	@Autowired
	private CourseService courseService;
//	@PostMapping("/saveCourse")  //  http://localhost:8881/saveCourse
//	public Course saveCourse(@RequestBody Course course ) {
//		return courseService.saveCourse(course);
//		
//	}
	@PostMapping("/saveCourse")
	public ResponseEntity<Course> saveCourse(@Valid @RequestBody Course course ){
		Course cour=courseService.saveCourse(course);
		return new ResponseEntity<>(cour,HttpStatus.CREATED);	
	}
	@GetMapping("/findByCourseId/{cid}")
	public Course findByCourseId(@PathVariable("cid")Integer courseid) throws GlobalExceptionHandling {
		return courseService.findByCourseId(courseid);
		
	}
	

}
