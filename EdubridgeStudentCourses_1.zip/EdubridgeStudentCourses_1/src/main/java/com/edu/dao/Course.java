package com.edu.dao;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Course {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer courseid;
	@Column(name = "Course_Name",length = 50,nullable = false)
	@NotBlank(message = "Enter the course name ")
	private String coursename;
	@Min(value = 5000,message = "minimum price is 5000")
	@Max(value = 25000,message = "maximum price is 25000")
	private float courseprice;
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	
//	@JsonIgnore
//	@ManyToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name="studentid" , referencedColumnName = "studentid")
//	Student stud;
	
	@OneToMany(mappedBy = "course")
	Set<Student> student=new HashSet<Student>();
	
	public Course(String coursename, float courseprice) {
		super();
		this.coursename = coursename;
		this.courseprice = courseprice;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public float getCourseprice() {
		return courseprice;
	}
	public void setCourseprice(float courseprice) {
		this.courseprice = courseprice;
	}
	@Override
	public String toString() {
		return "Course [courseid=" + courseid + ", coursename=" + coursename + ", courseprice=" + courseprice + "]";
	}
	

}
