package com.edu.dao;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer studentid;
	@Column(name = "student_name",length = 50,nullable = false)
	@NotBlank(message="Enter  the student name")
	private String studentname;
	@Min(value = 18 , message = "age is grater than 18")
	@Max(value = 50 , message = "age is less than 50")
	private Integer studentage;
	@Column(unique = true)
	@NotBlank(message = "Enter the student emailid")
	private String studentemail;
	@Future
	private Date studentdate;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
//	@OneToMany(mappedBy="stud")
//	Set<Course> course=new HashSet<Course>();
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="courseid" , referencedColumnName = "courseid")
	Course course;
	
	public Student(String studentname, Integer studentage, String studentemail, Date studentdate) {
		super();
		this.studentname = studentname;
		this.studentage = studentage;
		this.studentemail = studentemail;
		this.studentdate = studentdate;
	}
	public Integer getStudentid() {
		return studentid;
	}
	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public Integer getStudentage() {
		return studentage;
	}
	public void setStudentage(Integer studentage) {
		this.studentage = studentage;
	}
	public String getStudentemail() {
		return studentemail;
	}
	public void setStudentemail(String studentemail) {
		this.studentemail = studentemail;
	}
	public Date getStudentdate() {
		return studentdate;
	}
	public void setStudentdate(Date studentdate) {
		this.studentdate = studentdate;
	}
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentname=" + studentname + ", studentage=" + studentage
				+ ", studentemail=" + studentemail + ", studentdate=" + studentdate + "]";
	}
	
	

}
