package com.edu.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.dao.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {

	@Query(value="select * from Student where studentdate between ?1 AND ?2 ",nativeQuery = true)
	List<Student> findStudentbetweentwodate(Date studentdate, Date studentdate1);

	
}
