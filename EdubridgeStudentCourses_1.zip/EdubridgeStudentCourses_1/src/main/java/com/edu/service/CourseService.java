package com.edu.service;

import com.edu.dao.Course;
import com.edu.error.GlobalExceptionHandling;

public interface CourseService {

	  public Course saveCourse(Course course);

	public Course findByCourseId(Integer courseid) throws GlobalExceptionHandling;

	

}
