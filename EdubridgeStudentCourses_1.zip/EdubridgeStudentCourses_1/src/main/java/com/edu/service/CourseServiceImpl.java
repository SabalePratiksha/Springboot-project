package com.edu.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.Course;
import com.edu.error.GlobalExceptionHandling;
import com.edu.repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;
	
	
	@Override
	public Course saveCourse(Course course) {
		// TODO Auto-generated method stub
		return courseRepository.save(course);
	}


	@Override
	public Course findByCourseId(Integer courseid) throws GlobalExceptionHandling {
		// TODO Auto-generated method stub
		Optional<Course> course =courseRepository.findById(courseid);
		if(course.isPresent())
		{
			return courseRepository.findById(courseid).get();
		}
		else
		{
			throw new GlobalExceptionHandling("course id not foumd");
			
		}
	
	}


	

}
