package com.edu.service;

import java.sql.Date;
import java.util.List;

import com.edu.dao.Student;
import com.edu.error.GlobalExceptionHandling;

public interface StudentService {

	public Student saveStudent(Student student);

	public Student findByStudentId(Integer studentid) throws GlobalExceptionHandling;

	public List<Student> findStudentbetweentwodate(Date studentdate, Date studentdate1);

}
