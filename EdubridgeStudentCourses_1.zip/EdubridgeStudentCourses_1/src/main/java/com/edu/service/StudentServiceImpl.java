package com.edu.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.Student;
import com.edu.error.GlobalExceptionHandling;
import com.edu.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}
	@Override
	public Student findByStudentId(Integer studentid) throws GlobalExceptionHandling {
		// TODO Auto-generated method stub
		Optional<Student> student=studentRepository.findById(studentid);
		if(student.isPresent())
		{
			return studentRepository.findById(studentid).get() ;
		}
		else
		{
			throw new GlobalExceptionHandling("student id not foumd");
		}
		
	}
	@Override
	public List<Student> findStudentbetweentwodate(Date studentdate, Date studentdate1) {
		// TODO Auto-generated method stub
		return studentRepository.findStudentbetweentwodate(studentdate,studentdate1);
	}

}

